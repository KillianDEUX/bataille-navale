var indexSectionsWithContent =
{
  0: "bcejmt",
  1: "bcejmt"
};

var indexSectionNames =
{
  0: "all",
  1: "classes"
};

var indexSectionLabels =
{
  0: "Tout",
  1: "Structures de données"
};

