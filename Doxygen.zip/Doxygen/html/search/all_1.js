var searchData=
[
  ['case_5fs',['case_s',['../structcase__s.html',1,'']]],
  ['coord_5fs',['coord_s',['../structcoord__s.html',1,'']]]
];
